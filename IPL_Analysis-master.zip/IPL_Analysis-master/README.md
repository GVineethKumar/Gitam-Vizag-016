# IPL_Analysis

Problem statement on IPL prediction
1.Display the count of matches based on the year wise
2.Plot a bar graph no. of matches won by each team in the year 2011
3.Print ManOfMatch count of each player in Hyderabad stadium

 With these problem you can analyze dataset of IPL
